import os
import zipfile
from datetime import datetime

# Ruta de la carpeta a respaldar
source_folder = r"C:\Users\dachb\Downloads\Proyecto_final\soluticket"
# Ruta de destino para el archivo ZIP
backup_folder = r"C:\Users\dachb\Downloads\Proyecto_final\backups"

def create_backup():
    # Asegurarse de que la carpeta de respaldos exista
    if not os.path.exists(backup_folder):
        os.makedirs(backup_folder)
    
    # Crear el nombre del archivo ZIP con la fecha actual
    timestamp = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
    zip_filename = os.path.join(backup_folder, f"soluticket_backup_{timestamp}.zip")
    
    # Crear el archivo ZIP
    with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as backup_zip:
        for root, dirs, files in os.walk(source_folder):
            for file in files:
                file_path = os.path.join(root, file)
                # Agregar al ZIP con una ruta relativa
                backup_zip.write(file_path, os.path.relpath(file_path, source_folder))
    
    print(f"Respaldo creado: {zip_filename}")

if __name__ == "__main__":
    create_backup()
